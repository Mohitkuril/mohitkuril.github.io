import React from 'react'

function SyntaxErrorsHappen() {
    return (
        <div style={{ textAlign: "center" }}>
            <h1>This is Home Page</h1>
            <p style={{ color: "red" }}>First Step : Insert the Players in DataBase</p>
            <p style={{ color: "blue" }}>Second Step : Show the Player list</p>
        </div >
    )
}

export default SyntaxErrorsHappen
